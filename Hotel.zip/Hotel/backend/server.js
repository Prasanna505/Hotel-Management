const express = require('express');
const mysql = require('mysql');
const cors = require('cors');
const bodyParser = require('body-parser');
const WebSocket = require('ws');
const Razorpay = require('razorpay');
const crypto = require('crypto');   


const app = express();
app.use(cors());
app.use(bodyParser.json());

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'hotel'
});

db.connect(err => {
    if (err) throw err;
    console.log('Database connected!');
});

const razorpay = new Razorpay({
    key_id: 'rzp_live_VAS64yWeHAj4XD',
});
const RAZORPAY_KEY_SECRET= 'Tem7DSz0a41PfACHe38QM2Wk';
// Create a WebSocket server

const wss = new WebSocket.Server({ noServer: true });

// Handle WebSocket connections
wss.on('connection', ws => {
    console.log('Client connected');
    ws.on('message', message => {
        console.log('Received:', message);
    });
    ws.on('close', () => {
        console.log('Client disconnected');
    });
});

// Upgrade the HTTP server to handle WebSocket connections
const server = app.listen(3001, () => {
    console.log('Server running on port 3001');
});

server.on('upgrade', (request, socket, head) => {
    wss.handleUpgrade(request, socket, head, ws => {
        wss.emit('connection', ws, request);
    });
});

// Place Order - Handle Cash Payments
app.post('/place-order', (req, res) => {
    const { dateTime, totalBill, totalBillWithTip, paymentMethod, items, tableNo, tip } = req.body;
    const formattedDate = new Date(dateTime).toISOString().slice(0, 19).replace('T', ' ');

    if (paymentMethod === 'Cash') {
        const insertOrderQuery = 'INSERT INTO pending_orders (date_time, total_bill_amount, payment_method, table_no, tip) VALUES (?, ?, ?, ?, ?)';
        db.query(insertOrderQuery, [formattedDate, totalBill, paymentMethod, tableNo, tip], (err, result) => {
            if (err) return res.status(500).json({ error: err.message });

            const orderId = result.insertId;
            const insertItemsQuery = 'INSERT INTO order_items (order_id, item_name, quantity) VALUES ?';
            const itemsData = items.map(item => [orderId, item.name, item.quantity]);

            db.query(insertItemsQuery, [itemsData], (err) => {
                if (err) return res.status(500).json({ error: err.message });

                // Notify all connected clients about the new order
                wss.clients.forEach(client => {
                    if (client.readyState === WebSocket.OPEN) {
                        client.send(JSON.stringify({
                            type: 'new_order',
                            orderId,
                            dateTime: formattedDate,
                            totalBill,
                            totalBillWithTip,
                            paymentMethod,
                            tableNo,
                            tip,
                            items: itemsData.map(([_, name, quantity]) => ({ item_name: name, quantity })) // Use item_name
                        }));
                    }
                });

                res.status(200).json({ message: 'Order placed successfully. Waiting for admin approval.' });
            });
        });
    } else {
        console.log("Inside server.js")
        const insertOrderQuery = 'INSERT INTO orders (date_time, total_bill_amount, payment_method, table_no, tip) VALUES (?, ?, ?, ?, ?)';
        console.log("Inside server.js",insertOrderQuery )
        db.query(insertOrderQuery, [formattedDate, totalBill, paymentMethod, tableNo, tip], (err, result) => {console.log("Inside server.js",err )
            if (err) return res.status(500).json({ error: err.message });
            

            const orderId = result.insertId;
            const insertItemsQuery = 'INSERT INTO order_details (order_id, item_name, quantity) VALUES ?';
            const itemsData = items.map(item => [orderId, item.name, item.quantity]);

            db.query(insertItemsQuery, [itemsData], (err) => {
                if (err) return res.status(500).json({ error: err.message });
                res.status(200).json({ message: 'Order placed successfully.' });
            });
        });
    }
});

app.post('/mark-as-paid', (req, res) => {
    const { orderId } = req.body;

    if (!orderId) {
        return res.status(400).json({ message: 'Order ID is required' });
    }

    db.beginTransaction((err) => {
        if (err) {
            console.error('Error starting transaction:', err);
            return res.status(500).json({ error: err.message });
        }

        db.query('SELECT * FROM pending_orders WHERE id = ?', [orderId], (err, results) => {
            if (err) {
                return db.rollback(() => {
                    console.error('Error fetching pending order:', err);
                    res.status(500).json({ error: err.message });
                });
            }

            if (results.length === 0) {
                return db.rollback(() => {
                    res.status(404).json({ message: 'Order not found' });
                });
            }

            const order = results[0];

            db.query(
                'INSERT INTO orders (table_no, date_time, total_bill_amount, payment_method) VALUES (?, ?, ?, ?)',
                [order.table_no, order.date_time, order.total_bill_amount, order.payment_method],
                (err, result) => {
                    if (err) {
                        return db.rollback(() => {
                            console.error('Error inserting order into orders table:', err);
                            res.status(500).json({ error: err.message });
                        });
                    }

                    const newOrderId = result.insertId;

                    db.query('SELECT * FROM order_items WHERE order_id = ?', [orderId], (err, items) => {
                        if (err) {
                            return db.rollback(() => {
                                console.error('Error fetching order items:', err);
                                res.status(500).json({ error: err.message });
                            });
                        }

                        const itemsData = items.map(item => [newOrderId, item.item_name, item.quantity]);
                        db.query(
                            'INSERT INTO order_details (order_id, item_name, quantity) VALUES ?',
                            [itemsData],
                            (err) => {
                                if (err) {
                                    return db.rollback(() => {
                                        console.error('Error inserting items into order_details:', err);
                                        res.status(500).json({ error: err.message });
                                    });
                                }

                                db.query('DELETE FROM order_items WHERE order_id = ?', [orderId], (err) => {
                                    if (err) {
                                        return db.rollback(() => {
                                            console.error('Error deleting order items:', err);
                                            res.status(500).json({ error: err.message });
                                        });
                                    }

                                    db.query('DELETE FROM pending_orders WHERE id = ?', [orderId], (err) => {
                                        if (err) {
                                            return db.rollback(() => {
                                                console.error('Error deleting pending order:', err);
                                                res.status(500).json({ error: err.message });
                                            });
                                        }

                                        db.commit((err) => {
                                            if (err) {
                                                return db.rollback(() => {
                                                    console.error('Error committing transaction:', err);
                                                    res.status(500).json({ error: err.message });
                                                });
                                            }

                                            // Notify all connected clients about the updated order
                                            wss.clients.forEach(client => {
                                                if (client.readyState === WebSocket.OPEN) {
                                                    client.send(JSON.stringify({
                                                        type: 'order_paid',
                                                        orderId: newOrderId,
                                                        tableNo: order.table_no,
                                                        items: items.map(item => ({
                                                            item_name: item.item_name,
                                                            quantity: item.quantity
                                                        }))
                                                    }));
                                                }
                                            });

                                            res.status(200).json({ message: 'Order marked as paid and finalized.' });
                                        });
                                    });
                                });
                            }
                        );
                    });
                }
            );
        });
    });
});


app.post('/verify-payment', (req, res) => {
    const { orderId, paymentId, signature } = req.body;

    const generatedSignature = crypto.createHmac('sha256',RAZORPAY_KEY_SECRET)
        .update(orderId + "|" + paymentId)
        .digest('hex');

    if (generatedSignature === signature) {
        // Payment is verified
        res.json({ success: true, message: 'Payment verified successfully' });
    } else {
        // Payment verification failed
        res.status(400).json({ success: false, message: 'Payment verification failed' });
    }
});

// Get Pending Orders (Admin) with item details
app.get('/pending-orders', (req, res) => {
    db.query(`
        SELECT po.*, oi.item_name, oi.quantity
        FROM pending_orders po
        LEFT JOIN order_items oi ON po.id = oi.order_id
    `, (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        const orders = {};
        results.forEach(row => {
            if (!orders[row.id]) {
                orders[row.id] = {
                    id: row.id,
                    date_time: row.date_time,
                    total_bill_amount: row.total_bill_amount,
                    payment_method: row.payment_method,
                    table_no: row.table_no,
                    items: []
                };
            }
            if (row.item_name) {
                orders[row.id].items.push({
                    item_name: row.item_name,
                    quantity: row.quantity
                });
            }
        });

        res.json(Object.values(orders));
    });
});

// Get Orders for Chef
app.get('/chef-orders', (req, res) => {
    db.query(`
        SELECT o.id, o.table_no, od.item_name, od.quantity
        FROM orders o
        LEFT JOIN order_details od ON o.id = od.order_id
        ORDER BY o.date_time DESC
    `, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });

        const orders = {};
        results.forEach(row => {
            if (!orders[row.id]) {
                orders[row.id] = {
                    id: row.id,
                    table_no: row.table_no,
                    items: []
                };
            }
            if (row.item_name) {
                orders[row.id].items.push({
                    item_name: row.item_name,
                    quantity: row.quantity
                });
            }
        });

        res.json(Object.values(orders));
    });
});
