import { BrowserRouter, Routes, Route } from "react-router-dom";
import './App.css';
import Welcomepage from "./welcomePage/Welcome"
import North from "./North/North"
import South from "./South/South"
import Chinese from "./Chinese/Chinese"
import 'bootstrap/dist/css/bootstrap.min.css';
import { CartProvider } from './CartContext';
import Cart from './cart/cart';
import Order from './order/Order';
import Admin from './Admin/Admin';
import Chef from './Chef/Checf';

function App() {
  return (
    <div>
      <CartProvider>
      <BrowserRouter>
      <Routes>
       
         <Route path="/" element={<Welcomepage/>}></Route>
         <Route path="/north" element={<North/>}></Route>
         <Route path="/south" element={<South/>}></Route>
         <Route path="/chinese" element={<Chinese/>}></Route>
         <Route path="/cart" element={<Cart />} />
         <Route path="/order" element={<Order />} />
         <Route path="/admin" element={<Admin />} />
         <Route path="/chef" element={<Chef />} />
      </Routes>
    </BrowserRouter>
    </CartProvider>
    </div>
  );
}

export default App;
