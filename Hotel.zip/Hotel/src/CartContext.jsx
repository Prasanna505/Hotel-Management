// src/CartContext.jsx
import React, { createContext, useState, useEffect } from 'react';

export const CartContext = createContext();

export const CartProvider = ({ children }) => {
    const [cartItems, setCartItems] = useState([]);
    const [upiOrders, setUpiOrders] = useState([]);
    const [cashOrders, setCashOrders] = useState([]);
    const [chefOrders, setChefOrders] = useState([]);

    useEffect(() => {
        const savedUpiOrders = JSON.parse(localStorage.getItem('upiOrders')) || [];
        const savedCashOrders = JSON.parse(localStorage.getItem('cashOrders')) || [];
        const savedChefOrders = JSON.parse(localStorage.getItem('chefOrders')) || [];
        setUpiOrders(savedUpiOrders);
        setCashOrders(savedCashOrders);
        setChefOrders(savedChefOrders);
    }, []);

    const addItemToCart = (item) => {
        const existingItem = cartItems.find(cartItem => cartItem.name === item.name);
        if (existingItem) {
            setCartItems(cartItems.map(cartItem =>
                cartItem.name === item.name ? { ...cartItem, quantity: cartItem.quantity + item.quantity } : cartItem
            ));
        } else {
            setCartItems([...cartItems, item]);
        }
    };

    const removeItemFromCart = (itemName) => {
        setCartItems(cartItems.filter(item => item.name !== itemName));
    };

    const decrementItemQuantity = (itemName) => {
        const updatedCart = cartItems.map(item => {
            if (item.name === itemName && item.quantity > 1) {
                return { ...item, quantity: item.quantity - 1 };
            }
            return item;
        }).filter(item => item.quantity > 0);
        setCartItems(updatedCart);
    };

    const placeOrder = (order) => {
        if (order.paymentMethod === 'UPI') {
            const updatedUpiOrders = [...upiOrders, order];
            setUpiOrders(updatedUpiOrders);
            localStorage.setItem('upiOrders', JSON.stringify(updatedUpiOrders));
        } else {
            const updatedCashOrders = [...cashOrders, order];
            setCashOrders(updatedCashOrders);
            localStorage.setItem('cashOrders', JSON.stringify(updatedCashOrders));
        }

        const updatedChefOrders = [...chefOrders, order];
        setChefOrders(updatedChefOrders);
        localStorage.setItem('chefOrders', JSON.stringify(updatedChefOrders));

        localStorage.setItem('newOrder', JSON.stringify(order)); // Notify other tabs of the new order
    };

    const confirmCashPayment = (orderIndex) => {
        const order = cashOrders[orderIndex];
        const updatedCashOrders = cashOrders.filter((_, index) => index !== orderIndex);
        const updatedUpiOrders = [...upiOrders, order];
        setCashOrders(updatedCashOrders);
        setUpiOrders(updatedUpiOrders);
        localStorage.setItem('cashOrders', JSON.stringify(updatedCashOrders));
        localStorage.setItem('upiOrders', JSON.stringify(updatedUpiOrders));
    };

    useEffect(() => {
        const handleStorageChange = (event) => {
            if (event.key === 'upiOrders') {
                setUpiOrders(JSON.parse(event.newValue));
            } else if (event.key === 'cashOrders') {
                setCashOrders(JSON.parse(event.newValue));
            } else if (event.key === 'chefOrders') {
                setChefOrders(JSON.parse(event.newValue));
            }
        };
        window.addEventListener('storage', handleStorageChange);
        return () => {
            window.removeEventListener('storage', handleStorageChange);
        };
    }, []);

    return (
        <CartContext.Provider value={{
            cartItems,
            setCartItems,
            addItemToCart,
            removeItemFromCart,
            decrementItemQuantity,
            placeOrder,
            upiOrders,
            cashOrders,
            chefOrders,
            confirmCashPayment
        }}>
            {children}
        </CartContext.Provider>
    );
};
