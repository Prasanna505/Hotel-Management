import React, { useState, useContext } from 'react';
import { Outlet, useNavigate } from 'react-router-dom';
import Button from 'react-bootstrap/Button';
import { CartContext } from '../CartContext';
import Horizontal from '../Navbar/Horizontal.jsx';
import Footer from '../Navbar/Footer.jsx';
import './North.css';
import starters from './images/soup.bmp';
import naan from './images/naan.png';
import curry from './images/curry.png';
import rice from './images/rice.png';
import thali from './images/thali.png';

const North = () => {
  const navigate = useNavigate();
  const [selectedCategory, setSelectedCategory] = useState('Starters');
  const { addItemToCart } = useContext(CartContext);
  const [quantities, setQuantities] = useState({});

  const images = {
    'Starters': [
      { id: 'soup', src: starters, name: 'Soup', price: 1, description: 'tomato,bread crumbs,cream' },
      { id: 'salad', src: starters, name: 'Salad', price: 150, description: 'tomato,bread crumbs,cream' },
      { id: 'samosa', src: starters, name: 'Samosa', price: 50, description: 'tomato,bread crumbs,cream' },
      { id: 'paneer-tikka', src: starters, name: 'Paneer Tikka', price: 200, description: 'tomato,bread crumbs,cream' },
      { id: 'aloo-tikki', src: starters, name: 'Aloo Tikki', price: 120, description: 'tomato,bread crumbs,cream' },
      { id: 'kebab', src: starters, name: 'Kebab', price: 180, description: 'tomato,bread crumbs,cream' },
    ],
    'Roti': [
      { id: 'naan', src: naan, name: 'Naan', price: 30 },
      { id: 'roti', src: naan, name: 'Roti', price: 20 },
      { id: 'paratha', src: naan, name: 'Paratha', price: 40 },
      { id: 'chapati', src: naan, name: 'Chapati', price: 25 },
      { id: 'kulcha', src: naan, name: 'Kulcha', price: 35 },
      { id: 'puri', src: naan, name: 'Puri', price: 30 },
    ],
    'Curry': [
      { id: 'paneer-butter-masala', src: curry, name: 'Paneer Butter Masala', price: 250 },
      { id: 'chicken-curry', src: curry, name: 'Chicken Curry', price: 300 },
      { id: 'dal-makhani', src: curry, name: 'Dal Makhani', price: 200 },
      { id: 'chole', src: curry, name: 'Chole', price: 180 },
      { id: 'rajma', src: curry, name: 'Rajma', price: 220 },
      { id: 'korma', src: curry, name: 'Korma', price: 270 },
    ],
    'Rice': [
      { id: 'biryani', src: rice, name: 'Biryani', price: 250 },
      { id: 'fried-rice', src: rice, name: 'Fried Rice', price: 200 },
      { id: 'jeera-rice', src: rice, name: 'Jeera Rice', price: 150 },
      { id: 'plain-rice', src: rice, name: 'Plain Rice', price: 100 },
      { id: 'pulao', src: rice, name: 'Pulao', price: 220 },
      { id: 'brown-rice', src: rice, name: 'Brown Rice', price: 180 },
    ],
    'Thali': [
      { id: 'veg-thali', src: thali, name: 'Veg Thali', price: 300 },
      { id: 'non-veg-thali', src: thali, name: 'Non-Veg Thali', price: 350 },
      { id: 'special-thali', src: thali, name: 'Special Thali', price: 400 },
      { id: 'deluxe-thali', src: thali, name: 'Deluxe Thali', price: 450 },
      { id: 'mini-thali', src: thali, name: 'Mini Thali', price: 250 },
      { id: 'executive-thali', src: thali, name: 'Executive Thali', price: 500 },
    ],
  };

  const handleAddToCart = (item, quantity) => {
    if (quantity === 0) {
      alert("Quantity must be greater than 0");
    } else {
      alert("Item added");
      addItemToCart({ ...item, quantity });
    }
  };

  const handleQuantityChange = (id, quantity) => {
    setQuantities(prevQuantities => ({
      ...prevQuantities,
      [id]: quantity
    }));
  };

  const goToCart = () => {
    navigate('/cart', { state: { category: selectedCategory } });
  };

  return (
    <>
      <nav className="horizontal-menu">
        <Horizontal />
      </nav>

      <nav className="vertical-menu">
        <ul>
          <br /><br />
          <h2>Starters</h2>
          <li
            className={selectedCategory === 'Starters' ? 'selected' : ''}
            onClick={() => setSelectedCategory('Starters')}
          >
            <img id="menu" src={starters} alt="Starters" />
          </li>

          <h2>Roti</h2>
          <li
            className={selectedCategory === 'Roti' ? 'selected' : ''}
            onClick={() => setSelectedCategory('Roti')}
          >
            <img id="menu" src={naan} alt="Roti" />
          </li>
          <h2>Curry</h2>
          <li
            className={selectedCategory === 'Curry' ? 'selected' : ''}
            onClick={() => setSelectedCategory('Curry')}
          >
            <img id="menu" src={curry} alt="Curry" />
          </li>
          <h2>Rice</h2>
          <li
            className={selectedCategory === 'Rice' ? 'selected' : ''}
            onClick={() => setSelectedCategory('Rice')}
          >
            <img id="menu" src={rice} alt="Rice" />
          </li>
          <h2>Thali</h2>
          <li
            className={selectedCategory === 'Thali' ? 'selected' : ''}
            onClick={() => setSelectedCategory('Thali')}
          >
            <img id="menu" src={thali} alt="Thali" />
          </li>
        </ul>
      </nav>

      <div className="content">
        <h1>Welcome to North Indian menu</h1>
        <div className="image-grid">
          {images[selectedCategory].map((item, index) => (
            <div key={index} className="image-box">
              <img src={item.src} alt={item.name} />
              <div className="item-details">
                <span id='name'>{item.name}</span>
              </div>
              <div className="des">
                <span id='description'>{item.description}</span>
              </div>
              <p className="price">₹{item.price}</p>
              <QuantityAddButton
                item={item}
                quantity={quantities[item.id] || 0}
                onQuantityChange={(quantity) => handleQuantityChange(item.id, quantity)}
                handleAddToCart={handleAddToCart}
              />
            </div>
          ))}
        </div>
        <Outlet />
      </div>

      <nav className="footer">
        <Footer />
      </nav>
    </>
  );
};

const QuantityAddButton = ({ item, quantity, onQuantityChange, handleAddToCart }) => {

  const incrementQuantity = () => onQuantityChange(quantity + 1);
  const decrementQuantity = () => onQuantityChange(quantity > 0 ? quantity - 1 : 0);

  return (
    <>
      <div className="quantity-add-button">
        <div className="quantity-controls">
          <Button id='button' onClick={decrementQuantity}>-</Button>
          <span>{quantity}</span>
          <Button id='button' onClick={incrementQuantity}>+</Button>
        </div>

      </div>
      <Button variant='success' id="add" onClick={() => handleAddToCart(item, quantity)}>Add</Button>
    </>
  );
};

export default North;
