// src/components/Cart.jsx
import React, { useContext } from 'react';
import { CartContext } from '../CartContext';
import { useNavigate } from 'react-router-dom';
import './cart.css';

const Cart = () => {
  const { cartItems, removeItemFromCart, decrementItemQuantity, addItemToCart } = useContext(CartContext);
  const navigate = useNavigate();

  const handleIncrementQuantity = (item) => {
    addItemToCart({ ...item, quantity: 1 });
  };

  const goToOrderPage = () => {
    navigate('/order');
  };

  return (
    <div className="cart">
      <h1>Your Cart</h1>
      <ul>
        {cartItems.map((item, index) => (
          <li key={index} className="cart-item">
            <img src={item.src} alt={item.name} />
            <div className="item-details-cart">
              <span>{item.name}</span>
              <span>Quantity: {item.quantity}</span>
              <span>Price: ₹{item.price * item.quantity}</span>
            </div>
            <div className="quantity-controls" id='quantity-btn'>
              <button onClick={() => decrementItemQuantity(item.name)} className="quantity-button">-</button>
              <span>{item.quantity}</span>
              <button onClick={() => handleIncrementQuantity(item)} className="quantity-button">+</button>
            </div>
            <button onClick={() => removeItemFromCart(item.name)} className="remove-button">
              Remove
            </button>
          </li>
        ))}
      </ul>
      <footer className="footer-cart">
        <div className="left-footer">
          <button className="cart-button" onClick={goToOrderPage}>
            Order
          </button>
        </div>
        <div className="right-footer">
          <button className="back-button" onClick={() => navigate('/north')}>
            Back
          </button>
        </div>
      </footer>
    </div>
  );
};

export default Cart;
