import { Outlet, Link } from "react-router-dom";

const Welcome = () => {
  return (
    <>
      <nav>
      <ul>
          <li>
            <Link to="/north">North Indian</Link>
          </li>
        
          <li>
            <Link to="/chinese">Chinese</Link>
          </li>
         
        </ul>
        
        
      </nav>

            <h1>Welcome to South Indian menu</h1>
      <Outlet />
    </>
  )
};

export default Welcome;
