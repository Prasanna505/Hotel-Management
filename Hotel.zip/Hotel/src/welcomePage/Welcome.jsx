import { Outlet, Link } from "react-router-dom";
import './Welcome.css'

const Welcome = () => {
  return (
    <>
      <nav className="body" >
        <ul >
          <li >
            <Link to="/north" className="north" >North Indian</Link>
          </li>
          <li>
            <Link to="/south" className="south">South Indian</Link>
          </li>
          <li>
            <Link to="/chinese" className="chinese">Chinese</Link>
          </li>
          <li>
            <Link to="/special" className="special1">Today's Special</Link>
          </li>
          <li>
            <Link to="/special2" className="special2">Today's Special2</Link>
          </li>

        </ul>
      </nav>

      <Outlet />
    </>
  )
};

export default Welcome;
