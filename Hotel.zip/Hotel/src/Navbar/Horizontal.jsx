import React, { useState } from 'react';
import { Outlet, Link, useNavigate } from 'react-router-dom';
import './Navbar.css';

const Horizontal = () => {
  
  return (
    <>
      <nav className="horizontal-menu">
        <ul>
          <li>
            <Link to="/north">North Indian</Link>
          </li>
          <li>
            <Link to="/south">South Indian</Link>
          </li>
          <li>
            <Link to="/chinese">Chinese</Link>
          </li>
        </ul>

      </nav>

    
    </>
  );
};

export default Horizontal;
