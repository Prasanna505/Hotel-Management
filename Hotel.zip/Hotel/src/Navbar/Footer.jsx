import React, { useState } from 'react';
import { Outlet, Link, useNavigate } from 'react-router-dom';
import Button from 'react-bootstrap/Button';

import './Navbar.css';


const Footer = () => {
  const navigate = useNavigate();
  const [selectedCategory, setSelectedCategory] = useState('Starters');


  const handleCartButtonClick = () => {

    navigate('/cart');
  };


  return (
    <>


      <footer className="footer">
        <div className="left-footer">
          <button className="cart-button" onClick={handleCartButtonClick}>
            <i className="fas fa-shopping-cart"></i> Cart
          </button>
        </div>
        <div className="right-footer">
          <button className="back-button" onClick={() => navigate('/')}>
            Back
          </button>
        </div>
      </footer>
    </>
  );
};

export default Footer;
