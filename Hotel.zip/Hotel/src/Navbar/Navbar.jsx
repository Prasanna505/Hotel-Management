import React, { useState } from 'react';
import { Outlet, Link, useNavigate } from 'react-router-dom';
import Button from 'react-bootstrap/Button';

import './Navbar.css';
import starters from './images/soup.bmp';
import naan from './images/naan.png';
import curry from './images/curry.png';
import rice from './images/rice.png';
import thali from './images/thali.png';

const Navbar = () => {
  const navigate = useNavigate();
  const [selectedCategory, setSelectedCategory] = useState('Starters');

  const images = {
    'Starters': [
      { src: starters, name: 'Soup', price: 100 },
      { src: starters, name: 'Salad', price: 150 },
      { src: starters, name: 'Samosa', price: 50 },
      { src: starters, name: 'Paneer Tikka', price: 200 },
      { src: starters, name: 'Aloo Tikki', price: 120 },
      { src: starters, name: 'Kebab', price: 180 },
    ],
    'Roti': [
      { src: naan, name: 'Naan', price: 30 },
      { src: naan, name: 'Roti', price: 20 },
      { src: naan, name: 'Paratha', price: 40 },
      { src: naan, name: 'Chapati', price: 25 },
      { src: naan, name: 'Kulcha', price: 35 },
      { src: naan, name: 'Puri', price: 30 },
    ],
    'Curry': [
      { src: curry, name: 'Paneer Butter Masala', price: 250 },
      { src: curry, name: 'Chicken Curry', price: 300 },
      { src: curry, name: 'Dal Makhani', price: 200 },
      { src: curry, name: 'Chole', price: 180 },
      { src: curry, name: 'Rajma', price: 220 },
      { src: curry, name: 'Korma', price: 270 },
    ],
    'Rice': [
      { src: rice, name: 'Biryani', price: 250 },
      { src: rice, name: 'Fried Rice', price: 200 },
      { src: rice, name: 'Jeera Rice', price: 150 },
      { src: rice, name: 'Plain Rice', price: 100 },
      { src: rice, name: 'Pulao', price: 220 },
      { src: rice, name: 'Brown Rice', price: 180 },
    ],
    'Thali': [
      { src: thali, name: 'Veg Thali', price: 300 },
      { src: thali, name: 'Non-Veg Thali', price: 350 },
      { src: thali, name: 'Special Thali', price: 400 },
      { src: thali, name: 'Deluxe Thali', price: 450 },
      { src: thali, name: 'Mini Thali', price: 250 },
      { src: thali, name: 'Executive Thali', price: 500 },
    ],
  };

  return (
    <>
      <nav className="horizontal-menu">
        <ul>
          <li>
            <Link to="/north">North Indian</Link>
          </li>
          <li>
            <Link to="/south">South Indian</Link>
          </li>
          <li>
            <Link to="/chinese">Chinese</Link>
          </li>
        </ul>

      </nav>

      <nav className="vertical-menu">
        <ul>
          <h2>Starters</h2>
          <li onClick={() => setSelectedCategory('Starters')}>
            <img id="menu" src={starters} alt="Starters" />
          </li>
          <h2>Roti</h2>
          <li onClick={() => setSelectedCategory('Roti')}>
            <img id="menu" src={naan} alt="Roti" />
          </li>
          <h2>Curry</h2>
          <li onClick={() => setSelectedCategory('Curry')}>
            <img id="menu" src={curry} alt="Curry" />
          </li>
          <h2>Rice</h2>
          <li onClick={() => setSelectedCategory('Rice')}>
            <img id="menu" src={rice} alt="Rice" />
          </li>
          <h2>Thali</h2>
          <li onClick={() => setSelectedCategory('Thali')}>
            <img id="menu" src={thali} alt="Thali" />
          </li>
        </ul>
      </nav>

     

      <footer className="footer">
        <div className="left-footer">
          <button className="cart-button">
            <i className="fas fa-shopping-cart"></i> Cart
          </button>
        </div>
        <div className="right-footer">
          <button className="back-button" onClick={() => navigate('/')}>
            Back
          </button>
        </div>
      </footer>
    </>
  );
};

export default Navbar;
