import React, { useEffect, useState } from 'react';
import axios from 'axios';

const ChefPage = () => {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const response = await axios.get('http://localhost:3001/chef-orders');
        setOrders(response.data);
      } catch (error) {
        console.error('Error fetching orders:', error);
      }
    };

    fetchOrders();

    const ws = new WebSocket('ws://localhost:3001');
    ws.onmessage = (message) => {
      const data = JSON.parse(message.data);
      if (data.type === 'order_paid') {
        setOrders(prevOrders => [
          ...prevOrders,
          {
            id: data.orderId,
            table_no: data.tableNo,
            items: data.items
          }
        ]);
      }
    };

    return () => {
      ws.close();
    };
  }, []);

  return (
    <div>
      <h1>Chef Orders</h1>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Table No</th>
            <th>Items</th>
          </tr>
        </thead>
        <tbody>
          {orders.map(order => (
            <tr key={order.id}>
              <td>{order.id}</td>
              <td>{order.table_no}</td>
              <td>
                {order.items && order.items.map((item, index) => (
                  <div key={index}>
                    {item.item_name} (x{item.quantity})
                  </div>
                ))}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ChefPage;
