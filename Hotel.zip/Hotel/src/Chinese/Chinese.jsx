import { Outlet, Link } from "react-router-dom";
<link rel="stylesheet" href="chinese.css.css"/>

const Welcome = () => {
  return (
    <>
      <nav>
      <ul id="list">
         
          <li>
            <Link to="/north">North Indian</Link>
          </li>
          <li>
            <Link to="/south">South Indian</Link>
          </li>
         
        </ul>
         
      </nav>
            <h1>Welcome to Chinese menu</h1>

      <Outlet />
    </>
  )
};

export default Welcome;
