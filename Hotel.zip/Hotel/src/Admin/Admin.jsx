import React, { useEffect, useState } from 'react';
import axios from 'axios';
import WebSocket from 'isomorphic-ws';

const AdminPage = () => {
    const [orders, setOrders] = useState([]);
    const ws = new WebSocket('ws://localhost:3001');

    useEffect(() => {
        const fetchOrders = async () => {
            try {
                const response = await axios.get('http://localhost:3001/pending-orders');
                const ordersWithDefaultValues = response.data.map(order => ({
                    ...order,
                    total_bill_with_tip: order.total_bill_with_tip || 0,
                    tip: order.tip || 0
                }));
                setOrders(ordersWithDefaultValues);
            } catch (error) {
                console.error('Error fetching orders:', error);
            }
        };

        fetchOrders();

        ws.onmessage = (message) => {
            const data = JSON.parse(message.data);
            if (data.type === 'order_paid') {
                setOrders(prevOrders => prevOrders.filter(order => order.id !== data.orderId));
            } else if (data.type === 'new_order') {
                const newOrder = {
                    id: data.orderId,
                    date_time: data.dateTime,
                    total_bill_amount: data.totalBill || 0,
                    total_bill_with_tip: data.totalBillWithTip,
                    payment_method: data.paymentMethod || '',
                    table_no: data.tableNo || '',
                    tip: data.tip || 0,
                    items: data.items || []
                };
                setOrders(prevOrders => [...prevOrders, newOrder]);
            }
        };

        return () => {
            ws.close();
        };
    }, []);

    const handleMarkAsPaid = async (orderId) => {
        try {
            await axios.post('http://localhost:3001/mark-as-paid', { orderId });
            setOrders(prevOrders => prevOrders.filter(order => order.id !== orderId));
        } catch (error) {
            console.error('Error marking order as paid:', error);
        }
    };

    return (
        <div>
            <h1>Admin Orders</h1>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Date Time</th>
                        <th>Total Bill (with GST)</th>
                        <th>Total Bill (with GST & Tip)</th>
                        <th>Tip</th>
                        <th>Payment Method</th>
                        <th>Table No</th>
                        <th>Items</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {orders.map(order => (
                        <tr key={order.id}>
                            <td>{order.id}</td>
                            <td>{order.date_time}</td>
                            <td>₹{order.total_bill_amount.toFixed(2)}</td>
                            <td>₹{order.total_bill_with_tip.toFixed(2)}</td>
                            <td>₹{order.tip.toFixed(2)}</td>
                            <td>{order.payment_method}</td>
                            <td>{order.table_no}</td>
                            <td>
                                {order.items.map((item, index) => (
                                    <div key={index}>
                                        {item.item_name} (x{item.quantity})
                                    </div>
                                ))}
                            </td>
                            <td>
                                <button onClick={() => handleMarkAsPaid(order.id)}>
                                    Mark as Paid
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default AdminPage;
